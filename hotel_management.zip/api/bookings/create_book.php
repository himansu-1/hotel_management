<?php
session_start();
ob_start();
require_once('../../config/config.php');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $room_number = $_POST['room_number'] ?? "";
  $serial_number = $_POST['serial_number'] ?? "";
  $status = $_POST['status'] ?? "";
  $checkin_date = $_POST['checkin_date'] ?? "";
  $name = $_POST['name'] ?? "";
  $email = $_POST['email'] ?? "";
  $mobile = $_POST['mobile'] ?? "";
  $address = $_POST['address'] ?? "";
  $id_no = $_POST['id_no'] ?? "";
  $description = $_POST['description'] ?? "";
  $pay_mode = $_POST['pay_mode'] ?? "";
  $staying = $_POST['staying'] ?? "";
  $sub_total = $_POST['sub_total'] ?? "";
  $cgst = $_POST['cgst'] ?? "";
  $sgst = $_POST['sgst'] ?? "";
  $discount = $_POST['discount'] ?? "";
  $additional_charges = $_POST['additional_charges'] ?? "";
  $total_amount = $_POST['total_amount'] ?? "";
  $due_amount = $_POST['due_amount'] ?? "";
  $paid_amount = $_POST['paid_amount'] ?? "";
  try {
    // Validate required fields
    if (empty($room_number) || empty($name) || empty($checkin_date) || empty($status) || empty($pay_mode) || empty($sub_total) || empty($additional_charges) || empty($total_amount) || empty($due_amount) || empty($paid_amount) || empty($staying) || empty($total_amount)) {
      throw new Exception("Important fields are required.");
    }

    // File upload handling
    $upload_dir = "../../uploads/";
    $document_1 = $_FILES['document_1']['name'] ? time() . "_" . basename($_FILES['document_1']['name']) : "";
    $document_2 = $_FILES['document_2']['name'] ? time() . "_" . basename($_FILES['document_2']['name']) : "";
    $document_3 = $_FILES['document_3']['name'] ? time() . "_" . basename($_FILES['document_3']['name']) : "";

    if ($document_1) move_uploaded_file($_FILES['document_1']['tmp_name'], $upload_dir . $document_1);
    if ($document_2) move_uploaded_file($_FILES['document_2']['tmp_name'], $upload_dir . $document_2);
    if ($document_3) move_uploaded_file($_FILES['document_3']['tmp_name'], $upload_dir . $document_3);

    // Begin transaction
    $connect->beginTransaction();

    // Insert booking details
    $sql = "INSERT INTO bookings (
          room_number, 
          sl_no, 
          name, 
          mail, 
          mobile, 
          address, 
          aadhar_no, 
          other, 
          status, 
          checkin_date, 
          staying, 
          pay_mode, 
          sub_total, 
          cgst, 
          sgst, 
          discount, 
          additional_charges, 
          total_amount, 
          due_amount, 
          paid_amount
        ) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $connect->prepare($sql);
    $stmt->execute([
      $room_number,
      $serial_number,
      $name,
      $email,
      $mobile,
      $address,
      $id_no,
      $description,
      $status,
      $checkin_date,
      $staying,
      $pay_mode,
      $sub_total,
      $cgst,
      $sgst,
      $discount,
      $additional_charges,
      $total_amount,
      $due_amount,
      $paid_amount
    ]);

    // Get last inserted booking ID
    $booking_id = $connect->lastInsertId();

    // Insert into payments table
    if ($paid_amount > 0) {
      $payment_sql = "INSERT INTO payments (booking_id, date, pay_mode, amount) VALUES (?, NOW(), ?, ?)";
      $payment_stmt = $connect->prepare($payment_sql);
      $payment_stmt->execute([$booking_id, $pay_mode, $paid_amount]);
    }

    // Commit transaction
    $connect->commit();

    echo json_encode(['success' => true, 'message' => 'Booking successful', 'room_number' => $room_number, 'booking_id' => $booking_id]);
  } catch (Exception $e) {
    // Rollback transaction on error
    $connect->rollBack();
    echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
  }
} else {
  echo json_encode(['success' => false, 'message' => 'Invalid request']);
}

ob_end_flush();
