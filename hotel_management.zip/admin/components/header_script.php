<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" href="<?= $baseurl ?>assets/images/favicon.png" />
<link
  rel="icon"
  href="<?= $baseurl ?>assets/images/favicon.png"
  type="image/x-icon" />
<link
  rel="apple-touch-icon"
  sizes="180x180"
  href="<?= $baseurl ?>assets/images/favicon.png" />
<link
  rel="icon"
  type="image/png"
  sizes="32x32"
  href="<?= $baseurl ?>assets/images/favicon.png" />
<link
  rel="icon"
  type="image/png"
  sizes="16x16"
  href="<?= $baseurl ?>assets/images/favicon.png" />
<!-- base:css -->
<link rel="stylesheet" href="<?= $baseurl ?>assets/vendors/typicons/typicons.css">
<link rel="stylesheet" href="<?= $baseurl ?>assets/vendors/css/vendor.bundle.base.css">
<!-- endinject -->
<!-- inject:css -->
<link rel="stylesheet" href="<?= $baseurl ?>assets/css/vertical-layout-light/style.css">
<link rel="stylesheet" href="<?= $baseurl ?>assets/css/vertical-layout-light/bootstrap.min.css">
<!-- endinject -->



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />